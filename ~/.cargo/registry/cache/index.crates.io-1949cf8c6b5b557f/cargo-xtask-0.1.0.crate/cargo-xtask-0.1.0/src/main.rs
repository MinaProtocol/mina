fn main() {
    println!("See https://github.com/matklad/cargo-xtask/");
}
